// Select the button and elements
const styleToggleBtn = document.getElementById("styleToggleBtn");
const sections = [document.getElementById("about"), document.getElementById("services"), document.getElementById("Experience"), document.getElementById("Projects"), document.getElementById("contact")];
const navbar = document.getElementById("navbar");
const body = document.body;
const images = document.querySelectorAll("img"); // Select all images

// Define enhanced styles
const newStyles = {
  backgroundColor: "linear-gradient(to bottom, #0f2027, #203a43, #2c5364)", // Gradient background
  textColor: "#ffffff", // White text color
  boxShadow: "0 4px 20px rgba(255, 255, 255, 0.2)", // Glow effect
  imageBorder: "10px solidrgb(76, 144, 175)", // Image border
  imageShadow: "0 10px 20px rgba(0, 0, 0, 0.5)", // Shadow for images
  transition: "all 0.3s ease-in-out", // Smooth transitions
  
};

const defaultStyles = {
  backgroundColor: "",
  textColor: "",
  boxShadow: "",
  imageBorder: "",
  imageShadow: "",
  transition: "all 0.3s ease-in-out",
};

// Function to toggle styles
let stylesApplied = false;
function toggleStyles() {
  stylesApplied = !stylesApplied;

  // Toggle styles for body
  body.style.background = stylesApplied ? newStyles.backgroundColor : "#f4f4f4";
  body.style.transition = newStyles.transition;

  // Toggle styles for navbar
  navbar.style.background = stylesApplied ? "linear-gradient(to right,rgb(95, 151, 255), #feb47b)" : "lightblue";
  navbar.style.color = stylesApplied ? newStyles.textColor : "#333";
  navbar.style.boxShadow = stylesApplied ? newStyles.boxShadow : "";

  // Toggle styles for sections
  sections.forEach((section) => {
    section.style.background = stylesApplied ? "rgba(255, 255, 255, 0.1)" : "";
    section.style.color = stylesApplied ? newStyles.textColor : "#333";
    section.style.boxShadow = stylesApplied ? newStyles.boxShadow : "";
    section.style.borderRadius = "15px"; // Rounded edges
    section.style.transition = newStyles.transition;
    section.style.padding = "20px";
    section.style.margin="20px";
  });

  // Style images
  images.forEach((img) => {
    img.style.border = stylesApplied ? newStyles.imageBorder : "";
    img.style.boxShadow = stylesApplied ? newStyles.imageShadow : "";
    img.style.borderRadius = "50%";
    img.style.transition = newStyles.transition;
    img.style.width= "10%";
  });

  // Style the button
  styleToggleBtn.style.background = stylesApplied ? "linear-gradient(to right, #6a11cb, #2575fc)" : "#3949ab";
  styleToggleBtn.style.color = "#fff";
  styleToggleBtn.style.border = "none";
  styleToggleBtn.style.padding = "10px 20px";
  styleToggleBtn.style.borderRadius = "10px";
  styleToggleBtn.style.boxShadow = stylesApplied ? "0 4px 20px rgba(0, 0, 0, 0.3)" : "";
  styleToggleBtn.style.cursor = "pointer";
  styleToggleBtn.style.transform = stylesApplied ? "scale(1.1)" : "";
  styleToggleBtn.style.transition = newStyles.transition;

  // Update button text
  styleToggleBtn.textContent = stylesApplied ? "Revert Styles" : "Apply New Styles";
}

// Add click event listener to button
styleToggleBtn.addEventListener("click", toggleStyles);
